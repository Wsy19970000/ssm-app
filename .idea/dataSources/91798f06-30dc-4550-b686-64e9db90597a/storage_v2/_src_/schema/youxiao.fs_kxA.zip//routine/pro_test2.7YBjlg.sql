create procedure pro_test2(IN i int)
begin
	case i
		when 1 then
			SELECT '拨打爸爸的号码' as '提示';
		when 2 THEN
			SELECT '拨打妈妈的号码' AS '提示';
		when 3 THEN
			SELECT '拨打爷爷的号码' AS '提示';
		when 4 THEN
			SELECT '拨打奶奶的号码' AS '提示';
		else
			SELECT '输入有误' AS '提示';
	end case;
end;

