create procedure pro_test1(IN i int)
begin
	if i=1 then
		select '拨打爸爸的号码';
	elseif i=2 then
		SELECT '拨打妈妈的号码';
	elseif i=3 then
		SELECT '拨打爷爷的号码';
	elseif i=4 then
		select '拨打奶奶的号码';
	else
		select '输入有误';
	end if;
end;

