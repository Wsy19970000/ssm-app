create view view_twomenu as
select `youxiao`.`system_authoriy`.`id`       AS `twoId`,
       `youxiao`.`system_authoriy`.`text`     AS `twoName`,
       `youxiao`.`system_authoriy`.`parentId` AS `parentId`
from `youxiao`.`system_authoriy`
where ((`youxiao`.`system_authoriy`.`parentId` <> 0) and (`youxiao`.`system_authoriy`.`flag` = '0'));

