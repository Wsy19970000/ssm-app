create procedure pro_loop(IN i int)
BEGIN 
	DECLARE n INT DEFAULT 1;
	ok:loop	
		INSERT INTO bank VALUES(NULL,FLOOR(RAND()*1000),CONCAT('110',i),CONCAT('test',i));
		set n=n+1;
		if n=i then
			leave ok;
		end if;
	end loop;
END;

