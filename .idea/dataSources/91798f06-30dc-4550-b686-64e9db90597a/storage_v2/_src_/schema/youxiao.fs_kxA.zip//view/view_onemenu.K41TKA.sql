create view view_onemenu as
select `youxiao`.`system_authoriy`.`id` AS `oneId`,`youxiao`.`system_authoriy`.`text` AS `oneName`
from `youxiao`.`system_authoriy`
where ((`youxiao`.`system_authoriy`.`parentId` = 0) and (`youxiao`.`system_authoriy`.`flag` = '0'));

