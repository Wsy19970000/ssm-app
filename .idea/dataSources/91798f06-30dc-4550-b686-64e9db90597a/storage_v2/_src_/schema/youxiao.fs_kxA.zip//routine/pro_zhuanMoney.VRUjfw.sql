create procedure pro_zhuanMoney(OUT rs varchar(20), IN cost float, IN inNo varchar(40), IN outNo varchar(40))
begin
	if cost>0 then
		UPDATE `bank` SET money=money-cost WHERE bankNo=outNo;
		UPDATE bank SET money=money+cost WHERE bankNo=inNo;
		set rs = '转账成功';
	else
		set rs = '转账失败';
	end if;
end;

